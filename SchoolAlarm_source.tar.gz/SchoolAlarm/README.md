# School Alarm (Android)

Plans tomorrow's (or the next school day's) alarms from your Pronote timetable.

## Build
1. Install Android Studio.
2. File > Open > select this `SchoolAlarm` folder. Let Gradle sync (it creates the wrapper itself).
3. Plug in your phone (USB debugging on) and press Run, or Build > Build APK(s) and copy the APK to your phone.

## Get your Pronote calendar link
Pronote has no public API, so the app reads Pronote's calendar export:
Pronote (web) > Agenda / Emploi du temps > "Exporter / Synchroniser l'agenda" (iCal, webcal link).
Paste that link into the app. Keep it private: it gives access to your timetable.

## First use
1. Paste the link, type the school address.
2. At home, press "I'm at home now".
3. Choose foot or scooter, speed, and traffic margin.
4. Save & plan, then allow notifications, location, and location "all the time".
5. On Xiaomi/Huawei/Samsung phones, set the app's battery mode to "Unrestricted" so alarms are never killed.

## What it does
- Leave time = first class start - trip time (route distance / your speed + traffic margin) - early buffer.
- Bag alarm (default 10 min before leaving): heads-up notification with toilet + bag reminder and exactly two loud beeps. Not repeating.
- Leave alarm: rings once (not repeating), shows every class of the day (time, subject, room) on the lock screen.
- Both have a "Stop" button that works from the lock screen.
- Neither goes off if your phone is farther than the set radius from home (default 300 m). If location can't be read, it rings anyway so you don't oversleep.
- Re-plans every 3 hours and after reboot, so timetable changes and cancelled classes are picked up.

## Limits
- Free routing has no live traffic: the traffic % is a fixed margin you set.
- The lock screen text may be shortened by your phone: pull the notification down to see all classes.
